def tamgiac(a,b,c):
    if a+b<=c or a+c<=b or b+c<=a:
        print("Khong phai tam giac")
    elif a**2+b**2==c**2 or a**2==b**2+c**2 or b**2==a**2==c**2:
        print("tam giac vuong")
    elif a==b or b==c or c==a:
        print("tam giac can")
    elif a==b==c:
        print("tam giac deu")
    else:
        print("tam giac thuong")
a,b,c= map(int,input().split())
tamgiac(a,b,c)
