def bai3(n):
    print("số cách là",n//2)
n=int(input())
bai3(n)
