def ok(n):
    print("số dấu phảy là",len(str(n))//3)
n=int(input())
ok(n)
