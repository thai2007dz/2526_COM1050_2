def lmao(n):
    c=0
    for i in range(1,n-2):
        s=0
        for j in range(i,i+3):
            s+=j
        if s==n:
            c+=1
    print("số cách là",c)
n=int(input())
lmao(n)
